def sum_squares(list items):
    cdef long long total = 0
    cdef int value

    for value in items:
        total += value * value

    return total