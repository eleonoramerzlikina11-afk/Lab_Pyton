import random
import time

#5.1
print("\n5.1\n")
mass = [1, 2, 3, 4, 5]
sum = 0
for i in mass:
    sum += i * i
print(sum)

#5.2
print("\n5.2\n")
import pyximport
pyximport.install()
import helpme
mass = [1, 2, 3, 4, 5]
result = helpme.summm(mass)
print(result)

#5.3
print("\n5.3\n")
N = 10000000
mass = [random.randint(1,100) for i in range(N)]

sum = 0
start1 = time.perf_counter()
for i in mass:
    sum += i * i
end1 = time.perf_counter()
print(sum)
print(end1 - start1)


start2 = time.perf_counter()
result = helpme.summm(mass)
end2 = time.perf_counter()
print(result)
print(end2 - start2)


