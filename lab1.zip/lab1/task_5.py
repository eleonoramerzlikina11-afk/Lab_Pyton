import random
import time
import pyximport

print("Задание 5.1")

def python_sum_squares(items):
    result = 0

    for item in items:
        result += item ** 2

    return result

sample = [3, 5, 7, 9, 11]

print("Исходный список:", sample)
print("Сумма квадратов:", python_sum_squares(sample))

print("\nЗадание 5.2")

pyximport.install()
import fast_calc

compiled_result = fast_calc.sum_squares(sample)
print("Результат Cython:", compiled_result)

print("\nЗадание 5.3")

size = 10 ** 7
data = [random.randint(1, 100) for _ in range(size)]

start = time.perf_counter()
python_result = python_sum_squares(data)
python_duration = time.perf_counter() - start

start = time.perf_counter()
cython_result = fast_calc.sum_squares(data)
cython_duration = time.perf_counter() - start

print("Python результат:", python_result)
print("Cython результат:", cython_result)

print(f"Время Python: {python_duration:.4f} сек.")
print(f"Время Cython: {cython_duration:.4f} сек.")

if cython_duration > 0:
    print(f"Ускорение: {python_duration / cython_duration:.2f} раз")