import numpy as np
import timeit

print("Задание 3.2")

matrix = np.memmap(
    "numpy_storage.dat",
    dtype="float64",
    mode="r",
    shape=(1000, 1000)
)

selected_row = matrix[150, :]
selected_column = matrix[:, 250]

print("Выбранная строка:")
print(selected_row)

print("\nВыбранный столбец:")
print(selected_column)

print("\nЗадание 3.3")

def read_rows():
    for index in range(1000):
        matrix[index, :].sum()

def read_columns():
    for index in range(1000):
        matrix[:, index].sum()

row_result = timeit.timeit(read_rows, number=10) / 10
column_result = timeit.timeit(read_columns, number=10) / 10

print(f"Обход по строкам: {row_result:.6f} сек.")
print(f"Обход по столбцам: {column_result:.6f} сек.")

if row_result != 0:
    print(f"Отношение времени: {column_result / row_result:.2f}")

del matrix