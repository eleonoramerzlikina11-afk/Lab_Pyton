def summm(list mass):
    cdef long long summ = 0
    cdef int i
    for i in mass:
        summ += i * i
    return summ
