import numpy as np
from scipy.sparse import random as random_sparse
import timeit

print("Задание 4.1")

generator = np.random.default_rng(42)

sparse_array = random_sparse(
    5,
    5,
    density=0.2,
    format="csr",
    random_state=generator
)

print("Матрица CSR:")
print(sparse_array.toarray())
print("Ненулевых элементов:", sparse_array.nnz)

print("\nЗадание 4.2")

coordinate_format = sparse_array.tocoo()
column_format = sparse_array.tocsc()

print("Формат COO:")
print(coordinate_format)

print("\nФормат CSC:")
print(column_format)

print("\nЗадание 4.3")

values = np.array([1, 3, 5, 7, 9])
product = sparse_array @ values

print("Вектор:", values)
print("Результат умножения:", product)

print("\nЗадание 4.4")

large_sparse = random_sparse(
    1000,
    1000,
    density=0.01,
    format="csr",
    random_state=generator
)

large_dense = large_sparse.toarray()
vector = generator.random(1000)

def sparse_multiply():
    return large_sparse @ vector

def dense_multiply():
    return large_dense @ vector

sparse_time = timeit.timeit(sparse_multiply, number=20) / 20
dense_time = timeit.timeit(dense_multiply, number=20) / 20

print(f"Разреженная матрица: {sparse_time:.8f} сек.")
print(f"Плотная матрица: {dense_time:.8f} сек.")

print("Разница:", abs(dense_time - sparse_time))