import numpy as np

print("Задание 2.1")

A = np.random.randint(-5, 11, size=(4, 5))
print("Исходный массив:\n", A)

print("\nВторая строка:")
print(A[1])

print("\nСтолбец с индексом 3:")
print(A[:, 3])

print("\nВыбранная область:")
print(A[1:4, 2:5])

print("\nЗадание 2.2")

row_ids = np.array([0, 2, 3])
col_ids = np.array([1, 4])

part = A[np.ix_(row_ids, col_ids)]
print("Выбранные элементы:\n", part)

print("\nЗадание 2.3")

A[A < 0] = 0
print("Массив после замены отрицательных чисел:\n", A)

print("\nЗадание 2.4")

B = np.array([[1], [3], [5], [7]])
C = np.array([[2, 4, 6, 8, 10]])

combined = np.add(B, C)

print("B:\n", B)
print("C:\n", C)
print("Результат broadcasting:\n", combined)
print("Форма результата:", combined.shape)