import numpy as np

print("Создание memory-mapped массива")

storage = np.memmap(
    "numpy_storage.dat",
    dtype="float64",
    mode="w+",
    shape=(1000, 1000)
)

storage[:] = np.random.uniform(0, 100, size=(1000, 1000))
storage.flush()

print("Файл успешно создан")
print("Фрагмент первой строки:")
print(storage[0, :10])

del storage