import numpy as np

print("Задание 1.1")

values = np.array([0.1, 0.2, 0.3], dtype=np.float32)
total = values.sum()

print("Значения:", values)
print("Сумма:", total)
print("Разница с 0.6:", abs(float(total) - 0.6))

print("\nЗадание 1.2")

precision_32 = np.finfo("float32").eps
precision_64 = np.finfo("float64").eps

print("Точность float32:", precision_32)
print("Точность float64:", precision_64)

print("\nЗадание 1.3")

a = n.float32(1.00000009)
b = n.float32(1.00000090)
print("a =", a)
print("b =", b)
print("b - a =", b - a)
print("Ожидали: 1×10^9")