import numpy as np

print("Задание 1.1")

values = np.array([0.1, 0.2, 0.3], dtype=np.float32)
total = values.sum()

print("Значения:", values)
print("Сумма:", total)
print("Разница с 0.6:", abs(float(total) - 0.6))

print("\nЗадание 1.2")

precision_32 = np.finfo("float32").eps
precision_64 = np.finfo("float64").eps

print("Точность float32:", precision_32)
print("Точность float64:", precision_64)

print("\nЗадание 1.3")

first = np.float32(1.0000001)
second = np.float32(1.0000000)

difference_32 = first - second
difference_64 = np.float64(1.0000001) - np.float64(1.0000000)

print("Первое число:", first)
print("Второе число:", second)
print("Разность float32:", difference_32)
print("Разность float64:", difference_64)